﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FMS
{
    public partial class Default : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        string ct = DateTime.Now.ToString("hh:mm:ss");
        DateTime StartTime;
        DateTime EndTime;
        DateTime dtCompare;
        BLL objBll = new BLL();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                string role = Session["Role"].ToString();
                if (role.Trim() == "Admin")
                {
                    dvAdmin.Visible = true;
                    this.DashAdmin();
                }
                else if (role.Trim() == "User")
                {
                    dvUser.Visible = true;
                    this.DashUser();
                }
                else
                {
                    Response.Write("<script>alert('Sorry! You are not a valid user to access this application or your account is disabled')</script>");
                    return;
                }
            }

        }
        public void DashAdmin()
        {
            con.Open();
            string strProduct = "select count(*) from tblProducts where Isavailable=1;";
            string strPaid = "select count(*) from tblProducts where Sale=1;";
            string strStore = "select count(*) from tblStores;";
            string strUsers = "select count(*) from UserLogin where Status=1;";
            string strWasted = "select count(*) from tblProducts where IsWasted=1;";
            SqlDataAdapter da = new SqlDataAdapter(strProduct + strPaid + strStore + strUsers + strWasted, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables.Count > 0)
            {
                lblProcs.Text = ds.Tables[0].Rows[0][0].ToString();
                lblPaid.Text = ds.Tables[1].Rows[0][0].ToString();
                lblStores.Text = ds.Tables[2].Rows[0][0].ToString();
                lblUsers.Text = ds.Tables[3].Rows[0][0].ToString();
                lblSoldOut.Text = ds.Tables[4].Rows[0][0].ToString();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "", "alert('Table Not Found')", true);
            }
            con.Close();
        }
        public void DashUser()
        {
            con.Open();
            string strProduct = "select * from tblCooking";
            SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();

        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            Label lblItemName = (Label)row.FindControl("lblItemName");
            Label lblQtyOnHand = (Label)row.FindControl("lblQtyOnHand");
            Label lblWastedToday = (Label)row.FindControl("lblWastedToday");
            Label lblAmountCook = (Label)row.FindControl("lblAmountCook");

            ImageButton ibQtyP = (ImageButton)row.FindControl("ibQtyP");
            ImageButton ibWasteP = (ImageButton)row.FindControl("ibWasteP");
            ImageButton ibAmountP = (ImageButton)row.FindControl("ibAmountP");
            ImageButton ibQtyN = (ImageButton)row.FindControl("ibQtyN");
            ImageButton ibWasteN = (ImageButton)row.FindControl("ibWasteN");
            ImageButton ibAmountN = (ImageButton)row.FindControl("ibAmountN");

            Label lblStart = (Label)row.FindControl("lblStart");
            Label lblExp = (Label)row.FindControl("lblExp");
            Label lblDuration = (Label)row.FindControl("lblDuration");
            Label lblEx = (Label)row.FindControl("lblEx");

            int lblQty = Convert.ToInt32(lblQtyOnHand.Text);
            int lblWst = Convert.ToInt32(lblWastedToday.Text);
            int lblAmt = Convert.ToInt32(lblAmountCook.Text);
            Button lblProdId = (Button)row.FindControl("btnEdit");
            if (e.CommandName == "ibQtyP")
            {
                ibQtyP.Enabled = true;
                if (lblQty > 1)
                {
                    lblQtyOnHand.Text = Convert.ToString(lblQty - 1);
                }
                else
                {
                    ibQtyP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibWasteP")
            {
                ibWasteP.Enabled = true;
                if (lblWst > 1)
                {
                    lblWastedToday.Text = Convert.ToString(lblWst - 1);
                }
                else
                {
                    ibWasteP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibAmountP")
            {
                ibAmountP.Enabled = true;
                if (lblAmt > 1)
                {
                    lblAmountCook.Text = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    ibAmountP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibQtyN")
            {
                ibQtyP.Enabled = true;
                lblQtyOnHand.Text = Convert.ToString(lblQty + 1);
            }
            else if (e.CommandName == "ibWasteN")
            {
                ibWasteP.Enabled = true;
                lblWastedToday.Text = Convert.ToString(lblWst + 1);
            }
            else if (e.CommandName == "ibAmountN")
            {
                ibAmountP.Enabled = true;
                lblAmountCook.Text = Convert.ToString(lblAmt + 1);
            }
            else if (e.CommandName == "Cook")
            {
                //this.ExpiryTime(lblItemName.Text);
                string strProduct = "select ExpTime from tblCooking where ItemName='" + lblItemName.Text + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(strProduct, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["item"] = lblItemName.Text;
                    string tm = ds.Tables[0].Rows[0]["ExpTime"].ToString();
                    lblStart.Text = DateTime.Now.ToString("hh:mm:ss");
                    lblExp.Text = tm.ToString();
                    StartTime = DateTime.Parse(lblStart.Text);
                    EndTime = DateTime.Parse(tm.TrimEnd());
                    TimeSpan ts = StartTime.TimeOfDay + EndTime.TimeOfDay;
                    lblExp.Text = ts.ToString();
                    string hr = ts.Hours.ToString();
                    lblDuration.Text = tm.ToString();
                    Session["exp"] = lblExp.Text;
                    // Session["item"] = lblItemName.Text;
                    TimeSpan TotalTime = TimeSpan.Parse(tm);
                    TimeSpan Percentage;
                    if (TotalTime != null)
                    {
                        var ticks = ((TotalTime.Ticks * 50) / 100);
                        Percentage = new TimeSpan(ticks);
                        Session["alert"] = ts - Percentage;
                        //TimeSpan timeSpan = TimeSpan.FromMilliseconds((Percentage.TotalMilliseconds * 50) / 100);

                    }
                    // Insert Data in Cooklog records

                    BAL obJBE = new BAL();
                    obJBE.IName = lblItemName.Text.Trim();
                    obJBE.Wasted = lblWastedToday.Text.Trim();
                    obJBE.ACooked = lblAmountCook.Text.Trim();
                    obJBE.ExpTime = tm.Trim();
                    obJBE.UserId = Session["UserId"].ToString().Trim();
                    obJBE.Name = DateTime.Now.ToString("ddMMMyyyy hh:mm:ss tt");
                    DataSet ds1 = new DataSet();
                    ds1 = objBll.CookedItem(obJBE);
                }
                con.Close();
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void timeCount_Tick(object sender, EventArgs e)
        {
            lblMarq.Text = lblMarq.Text;
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss");
            if (Session["exp"] != null)
            {
                string exp = Session["exp"].ToString();
                dtCompare = DateTime.Parse(exp);

                if (exp == lblTime.Text)
                {
                    Response.Write("<script>alert('Expiration Alert:::This Item has been expired....')</script>");
                }
            }
            if (Session["alert"] != null)
            {
                dvMarquee.Visible = true;
                string strAlert = Session["alert"].ToString();
                if (strAlert == lblTime.Text)
                {
                    lblMarq.Text = lblMarq.Text + Session["item"].ToString() + " Item will be expire after :" + strAlert;
                }
            }
        }
    }
}