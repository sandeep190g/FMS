﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FMS
{
    public class DAL
    {
        //SqlDBHelper sql = new SqlDBHelper();
        public DataSet LoginCredential(BAL belogin)
        {
            SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
            con.Open();
            string query = "select * from UserLogin where UserID=@UserID and Password=@Pass and Status=1;";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@UserId", belogin.UserId);
            cmd.Parameters.AddWithValue("@Pass", belogin.Password);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            return ds;
        }

        public DataSet CookingTable(BAL balCooking)
        {

            SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
            con.Open();
            string query = "procCooking";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ItemName", balCooking.IName);
            cmd.Parameters.AddWithValue("@UserID", balCooking.UserId);
            cmd.Parameters.AddWithValue("@ExpTime", balCooking.ExpTime);
            cmd.Parameters.AddWithValue("@AmountCooked", balCooking.ACooked);
            cmd.Parameters.AddWithValue("@CookedTime", balCooking.Name);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            return ds;
        }



    }
}