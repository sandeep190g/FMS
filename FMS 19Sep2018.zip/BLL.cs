﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace FMS
{
    public class BLL
    {
        DAL dAL = new DAL();
        BAL bAL = new BAL();
        public DataSet UserLogin(BAL bAL)
        {
            try
            {
                return dAL.LoginCredential(bAL);
            }
            catch
            {
                throw;
            }
        }
        public DataSet CookedItem(BAL bAL)
        {
            try
            {
                return dAL.CookingTable(bAL);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}