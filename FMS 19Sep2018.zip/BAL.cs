﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FMS
{
    public class BAL
    {


        private string userId;
        private string password;
        private string name;
        private string role;
        private string loc;

        private string iName;
        private string qtyHand;
        private string wasted;
        private string aCooked;
        private string expTime;


        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string UserId
        {
            get { return userId; }
            set { userId = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Role
        {
            get { return role; }
            set { role = value; }
        }
        public string Loc
        {
            get { return loc; }
            set { loc = value; }
        }

        public string IName
        {
            get { return iName; }
            set { iName = value; }
        }

        public string QtyHand
        {
            get { return qtyHand; }
            set { qtyHand = value; }
        }
        public string Wasted
        {
            get { return wasted; }
            set { wasted = value; }
        }
        public string ACooked
        {
            get { return aCooked; }
            set { aCooked = value; }
        }

        public string ExpTime
        {
            get { return expTime; }
            set { expTime = value; }
        }
    }
}