﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace FMS
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        BLL objBll = new BLL();
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        string LastCooked = "";
        string LastWasted = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lbLogout.ServerClick += new EventHandler(lbLogout_Click);
                if (Session["UserId"] == null)
                {
                    Response.Redirect("~/Home.aspx");
                }
                AddItem_Click();
            }//div1.Visible = true;
        }

        private void AddItem_Click()
        {
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("select Meals from tblTimeCode", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    int count = ds.Tables[0].Rows.Count;
                    siteBox.Text += "<section class='statistics'>";
                    siteBox.Text += "<div class='container-fluid'>";
                    siteBox.Text += "<div class='row d-flex'>";

                    for (int i = 0; i < count; i++)
                    {



                        siteBox.Text += " <div class='col-sm-4' style='border-radius:50%;'>";
                        siteBox.Text += "<div class='card income text-center'>";
                        siteBox.Text += " <div class='icon'><i class='icon-line-chart'></i></div>";
                        siteBox.Text += " </br><img src='Pictures/p04tx3m6.jpg' height='100px' width='100%' style='border-radius:50%; cursor:pointer;'/></br>";
                        siteBox.Text += "<strong class='text-primary'>";
                        siteBox.Text += "</br><input type='button' class='btn btn-success' value='" + ds.Tables[0].Rows[i][0].ToString() + "'></br>";
                        siteBox.Text += " </div></div> ";
                    }
                    siteBox.Text += "</div></div></section>";
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Items not found')", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ex.Message + "')", true);
            }
            finally
            {
                con.Close();
            }
        }
        private void lbLogout_Click(object sender, EventArgs e)
        {

            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
        public void CheckLastCooked()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select LastCookedAmount,LastWastedAmount from tblProduct", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                LastWasted = ds.Tables[0].Rows[0][0].ToString();
                LastWasted = ds.Tables[0].Rows[0][1].ToString();
            }
        }


        public void tblMenu()
        {
            while (true)
            {


            }
        }
        //protected void btnAdd_Click(object sender, EventArgs e)
        //{
        //    if (txtStoreID.Text.Trim() == "")
        //        Response.Write("<script>alert('Enter valid Store ID')</script>");
        //    else if (txtItemName.Text.Trim() == "")
        //        Response.Write("<script>alert('Enter valid Item Name')</script>");
        //    else if (txtExpTime.Text.Trim() == "")
        //        Response.Write("<script>alert('Enter valid Exp Time')</script>");
        //    else if (txtDuration.Text.Trim() == "")
        //        Response.Write("<script>alert('Enter valid Duration')</script>");
        //    CheckLastCooked();
        //    BAL obJBE = new BAL();
        //    obJBE.UserId = txtStoreID.Text.Trim();
        //    obJBE.IName = txtItemName.Text.Trim();
        //    obJBE.ExpTime = txtExpTime.Text.Trim();
        //    obJBE.Name = txtDuration.Text.Trim();
        //    obJBE.QtyHand = LastCooked;
        //    obJBE.Wasted = LastWasted;
        //    DataSet ds = new DataSet();
        //    ds = objBll.InsertItem(obJBE);
        //    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "", "alert('Item Added!!')", true);
        //    txtStoreID.Text = "";
        //    txtItemName.Text = "";
        //    txtExpTime.Text = "";
        //    txtDuration.Text = "";

        //}
    }
}