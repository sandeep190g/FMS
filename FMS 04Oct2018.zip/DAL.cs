﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FMS
{
    public class DAL
    {
        //SqlDBHelper sql = new SqlDBHelper();
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);

        public DataSet LoginCredential(BAL belogin)
        {
            con.Open();
            string query = "select * from UserLogin where UserID=@UserID and Password=@Pass and Status=1;";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@UserId", belogin.UserId);
            cmd.Parameters.AddWithValue("@Pass", belogin.Password);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            return ds;
        }

        public DataSet CookingTable(BAL balCooking)
        {

            //SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
            con.Open();
            string query = "ProcAdd";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StoreID", balCooking.StorID);
            cmd.Parameters.AddWithValue("@ItemName", balCooking.IName);
            cmd.Parameters.AddWithValue("@UPC", balCooking.UPC);
            cmd.Parameters.AddWithValue("@TimeCode", balCooking.TimeCode);
            cmd.Parameters.AddWithValue("@ExpTime", balCooking.ExpTime);
            cmd.Parameters.AddWithValue("@CookDur", balCooking.Loc);
            cmd.Parameters.AddWithValue("@CookedAmt", balCooking.QtyHand);
            cmd.Parameters.AddWithValue("@WastedAmt", balCooking.Wasted);
            cmd.Parameters.AddWithValue("@ImageUrl", balCooking.ImageUrl);
            cmd.Parameters.AddWithValue("@VideoUrl", balCooking.VideoUrl);
            cmd.Parameters.AddWithValue("@StepsUrl", balCooking.StepUrl);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            return ds;
        }
        public DataSet AddItem(BAL balAddItem)
        {
            con.Open();
            string query = "insert into tblProduct (StoreID,ItemName,Expirationtime,Cookduration,LastCookedAmount,LastWastedAmount) values (@Store,@Item,@ExpTime,@Duration,@LastCooked,@LastWasted);";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Store", balAddItem.UserId);
            //cmd.Parameters.AddWithValue("@UserID", balAddItem.UserId);
            cmd.Parameters.AddWithValue("@Item", balAddItem.IName);
            cmd.Parameters.AddWithValue("@ExpTime", balAddItem.ExpTime);
            cmd.Parameters.AddWithValue("@Duration", balAddItem.Name);
            cmd.Parameters.AddWithValue("@LastCooked", balAddItem.QtyHand);
            cmd.Parameters.AddWithValue("@LastWasted", balAddItem.Wasted);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            return ds;
        }


    }
}