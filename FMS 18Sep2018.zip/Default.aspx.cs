﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FMS
{
    public partial class Default : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                lblTime.Text = DateTime.Now.ToString("hh:mm:ss");
                string role = Session["Role"].ToString();
                if (role.Trim() == "Admin")
                {
                    dvAdmin.Visible = true;
                    this.DashAdmin();
                }
                else if (role.Trim() == "User")
                {
                    dvUser.Visible = true;
                    this.DashUser();
                }
                else
                {
                    Response.Write("<script>alert('Sorry! You are not a valid user to access this application or your account is disabled')</script>");
                    return;
                }
            }

        }
        //private string tm;

        public void DashAdmin()
        {
            con.Open();
            string strProduct = "select count(*) from tblProducts where Isavailable=1;";
            string strPaid = "select count(*) from tblProducts where Sale=1;";
            string strStore = "select count(*) from tblStores;";
            string strUsers = "select count(*) from UserLogin where Status=1;";
            string strWasted = "select count(*) from tblProducts where IsWasted=1;";
            SqlDataAdapter da = new SqlDataAdapter(strProduct + strPaid + strStore + strUsers + strWasted, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables.Count > 0)
            {
                lblProcs.Text = ds.Tables[0].Rows[0][0].ToString();
                lblPaid.Text = ds.Tables[1].Rows[0][0].ToString();
                lblStores.Text = ds.Tables[2].Rows[0][0].ToString();
                lblUsers.Text = ds.Tables[3].Rows[0][0].ToString();
                lblSoldOut.Text = ds.Tables[4].Rows[0][0].ToString();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "", "alert('Table Not Found')", true);
            }
            con.Close();
        }
        public void DashUser()
        {
            con.Open();
            string strProduct = "select * from tblCooking";
            SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //Response.Write("<script>alert('Hello Dear, How are you!')</script>");
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            Label lblItemName = (Label)row.FindControl("lblItemName");
            Label lblQtyOnHand = (Label)row.FindControl("lblQtyOnHand");
            Label lblWastedToday = (Label)row.FindControl("lblWastedToday");
            Label lblAmountCook = (Label)row.FindControl("lblAmountCook");

            //GridViewRow rowImg = (GridViewRow)(((Button)e.CommandSource).NamingContainer);

            ImageButton ibQtyP = (ImageButton)row.FindControl("ibQtyP");
            ImageButton ibWasteP = (ImageButton)row.FindControl("ibWasteP");
            ImageButton ibAmountP = (ImageButton)row.FindControl("ibAmountP");
            ImageButton ibQtyN = (ImageButton)row.FindControl("ibQtyN");
            ImageButton ibWasteN = (ImageButton)row.FindControl("ibWasteN");
            ImageButton ibAmountN = (ImageButton)row.FindControl("ibAmountN");






            int lblQty = Convert.ToInt32(lblQtyOnHand.Text);
            int lblWst = Convert.ToInt32(lblWastedToday.Text);
            int lblAmt = Convert.ToInt32(lblAmountCook.Text);



            Button lblProdId = (Button)row.FindControl("btnEdit");
            if (e.CommandName == "ibQtyP")
            {
                ibQtyP.Enabled = true;
                if (lblQty > 1)
                {
                    lblQtyOnHand.Text = Convert.ToString(lblQty - 1);
                }
                else
                {
                    ibQtyP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibWasteP")
            {
                ibWasteP.Enabled = true;
                if (lblWst > 1)
                {
                    lblWastedToday.Text = Convert.ToString(lblWst - 1);
                }
                else
                {
                    ibWasteP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibAmountP")
            {
                ibAmountP.Enabled = true;
                if (lblAmt > 1)
                {
                    lblAmountCook.Text = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    ibAmountP.Enabled = false;
                }
            }
            else if (e.CommandName == "ibQtyN")
            {
                //ibQtyN.Enabled = true;
                ibQtyP.Enabled = true;
                lblQtyOnHand.Text = Convert.ToString(lblQty + 1);
            }
            else if (e.CommandName == "ibWasteN")
            {
                ibWasteP.Enabled = true;
                lblWastedToday.Text = Convert.ToString(lblWst + 1);
            }
            else if (e.CommandName == "ibAmountN")
            {
                ibAmountP.Enabled = true;
                lblAmountCook.Text = Convert.ToString(lblAmt + 1);
            }
            else if (e.CommandName == "Cook")
            {
                this.ExpiryTime(lblItemName.Text);
            }


        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }


        protected void timeCount_Tick(object sender, EventArgs e)
        {
            TimeSpan ts = EndTime - StartTime;

        }
        string ct = DateTime.Now.ToString("hh:mm:ss");
        DateTime EndTime;
        DateTime StartTime;
        public void ExpiryTime(string Itm)
        {
            string strProduct = "select CookingTime from tblCooking where ItemName='" + Itm + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(strProduct, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                string tm = ds.Tables[0].Rows[0]["CookingTime"].ToString();
                EndTime = Convert.ToDateTime(tm);
                StartTime = DateTime.Parse(EndTime.ToString());
                //EndTime = DateTime.Parse("04:00 PM"); // It converts this to 1600.

            }
            con.Close();
        }
    }
}