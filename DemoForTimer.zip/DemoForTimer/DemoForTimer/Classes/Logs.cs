﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoForTimer.Classes
{
    public static class Logs
    {
        public static void SendMessage(string msg)
        {
            StreamWriter sw = null;
            try
            {
                string date = System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
                //sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\CLasses\\Logs " + date + ".txt", true);
                sw = new StreamWriter("D:\\Logs " + date + ".txt", true);
                sw.WriteLine(date + ":" + msg);
                sw.Flush();
                sw.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
