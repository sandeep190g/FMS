﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.Threading.Tasks;
using DemoForTimer.Classes;

namespace DemoForTimer
{
    public partial class Service1 : ServiceBase
    {

        private Timer timer = null;
        public Service1()
        {
            //pricaetMethid();
            InitializeComponent();
        }
        
        protected override void OnStart(string[] args)
        {
            Logs.SendMessage("Timer is set for 10 seconds..");
            timer = new Timer();
            this.timer.Interval = 10000;
            this.timer.Elapsed += new ElapsedEventHandler(this.timer_tick);
            this.timer.Enabled = true;
            Logs.SendMessage("Service had been started...");

        }

        private void timer_tick(object sender, EventArgs e)
        {
            Logs.SendMessage("Some programs is running in background.....");
            // after condition..

            Logs.SendMessage("Process has been completed.....");

        }

        protected override void OnStop()
        {
            Logs.SendMessage("Event On Stop.....");
            Logs.SendMessage("Attempt shutdown of service.....");
            // after condition..
            this.timer.Stop();
            timer = null;
            Logs.SendMessage("Process has Stop.....");
        }
    }
}
