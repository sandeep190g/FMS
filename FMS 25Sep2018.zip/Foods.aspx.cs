﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace FMS
{
    public partial class Foods : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        BLL objBll = new BLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                con.Open();
                string strProduct = "select * from tblProduct;";
                SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
                con.Close();
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            //Label lblItemName = (Label)row.FindControl("lblItemName");
            TextBox txtStoreID = (TextBox)row.FindControl("txtStoreID");
            TextBox txtItemName = (TextBox)row.FindControl("txtItemName");
            TextBox txtUPC = (TextBox)row.FindControl("txtUPC");
            TextBox txtTimeCode = (TextBox)row.FindControl("txtTimeCode");
            TextBox txtExpTime = (TextBox)row.FindControl("txtExpTime");
            TextBox txtCookDuration = (TextBox)row.FindControl("txtCookDuration");
            TextBox txtLastAmount = (TextBox)row.FindControl("txtLastAmount");
            TextBox txtLastWasted = (TextBox)row.FindControl("txtLastWasted");
            FileUpload fileVideo = (FileUpload)row.FindControl("fileVideo");
            FileUpload fileImage = (FileUpload)row.FindControl("fileImage");
            TextBox txtStepUrl = (TextBox)row.FindControl("txtStepUrl");
            Image img1 = (Image)row.FindControl("img1");

            Button btnAdd = (Button)row.FindControl("btnAdd");
            Button btnEdit = (Button)row.FindControl("btnEdit");

            if (e.CommandName == "Add")
            {
                string strpath = Server.MapPath("~/Pictuers/" + fileImage.PostedFile.FileName);
                fileImage.SaveAs(strpath);
                //string name = Path.GetFileName(fileImage.PostedFile.FileName);
                img1.ImageUrl = Path.GetFileName(strpath);
                byte[] img2 = null;
                FileStream fs = new FileStream(strpath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img2 = br.ReadBytes((int)fs.Length);






                //con.Open();
                BAL obJBE = new BAL();
                obJBE.ImageUrl = img2;
                obJBE.StorID = txtStoreID.Text.Trim();
                obJBE.IName = txtItemName.Text.Trim();
                obJBE.UPC = txtUPC.Text.Trim();
                obJBE.TimeCode = txtTimeCode.Text.Trim();
                obJBE.ExpTime = txtExpTime.Text.Trim();
                obJBE.Loc = txtCookDuration.Text.Trim();
                obJBE.QtyHand = txtLastAmount.Text.Trim();
                obJBE.Wasted = txtLastWasted.Text.Trim();
                obJBE.VideoUrl = fileVideo.PostedFile.FileName;
                obJBE.StepUrl = txtStepUrl.Text.Trim();
                DataSet ds1 = new DataSet();
                ds1 = objBll.CookedItem(obJBE);
            }


        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }
    }
}