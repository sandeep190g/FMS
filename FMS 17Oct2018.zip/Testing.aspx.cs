﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Timers;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Testing : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = "sandeep kumar singh";
            Encryptdata(name);
            string nm = strmsg;
            Response.Write(nm);

            Decryptdata(nm);
            string exc = decryptpwd;
            Response.Write("</br></br>" + exc);



            //string s1;
            //byte[] data = Encoding.UTF8.GetBytes("Golu");
            //using (SHA512 shaM = new SHA512Managed())
            //{
            //    byte[] result = shaM.ComputeHash(data);
            //    //string str=
            //    Response.Write(Convert.ToBase64String(result));
            //    Session["1"] = Convert.ToBase64String(result);
            //}
            //GetCrypt(Session["1"].ToString());





            //try
            //{
            //    System.Web.UI.Timer timeoutTimer = new System.Web.UI.Timer();
            //    timeoutTimer.ID = "timeouttimer";
            //    timeoutTimer.Interval = 1000;
            //    timeoutTimer.Tick += new EventHandler<EventArgs>(timeoutTimer_Tick);

            //    UpdatePanel timerUpdatePanel = new UpdatePanel();
            //    timerUpdatePanel.ContentTemplateContainer.Controls.Add(timeoutTimer);
            //    ScriptManager.GetCurrent(this.Page).RegisterAsyncPostBackControl(timeoutTimer);
            //    this.Page.Form.Controls.Add(timerUpdatePanel); base.OnInit(e);

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
        }
        public string strmsg;
        private string Encryptdata(string password)
        {
            strmsg = string.Empty;
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            strmsg = Convert.ToBase64String(encode);
            return strmsg;
        }
        /// <summary>
        /// Function is used to Decrypt the password
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public string decryptpwd;
        private string Decryptdata(string encryptpwd)
        {
            decryptpwd = string.Empty;
            UTF8Encoding encodepwd = new UTF8Encoding();
            Decoder Decode = encodepwd.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encryptpwd);
            int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            decryptpwd = new String(decoded_char);
            return decryptpwd;
        }

        public static string GetCrypt(string text)
        {
            string hash = "";
            SHA512 alg = SHA512.Create();
            byte[] result = alg.ComputeHash(Encoding.UTF8.GetBytes(text));
            hash = Encoding.UTF8.GetString(result);
            return hash;
        }
        protected void timeoutTimer_Tick(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Hello Testing" + DateTime.Now.ToString("hh: mm:ss") + "')", true);
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {

            //StringBuilder sb = new StringBuilder();

            //sb.Append(" <div class=\"dropdown\">");
            //sb.Append("   <button class=\"btn btn-default dropdown-toggle\" type=\"button\" id=\"dlStudentSelect\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"true\">");
            //sb.Append("     Dropdown");
            //sb.Append("     <span class=\"caret\"></span>");
            //sb.Append("   </button>");
            //sb.Append("   <ul class=\"dropdown-menu\" id=\"studentMenu\" aria-labelledby=\"bstpDdlPlayerSelect\">");

            //foreach (string student in students)
            //{
            //    sb.Append($"     <li><a href=\"#\">{student.ToString()}</a></li>");
            //}

            //sb.Append(" </select>");
            //sb.Append("   </ul>");
            //sb.Append(" </div>");

            //ddlPlayerSelect.Text = sb.ToString();






            //ModalPopupExtender1.Show();
        }
    }
}