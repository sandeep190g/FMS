﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;
using FMS.Classes;
namespace FMS
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        FMSClass fms = new FMSClass();
        BLL objBll = new BLL();
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        string LastCooked = "";
        string LastWasted = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            lbLogout.ServerClick += new EventHandler(lbLogout_Click);
            lbAddItem.ServerClick += new EventHandler(lbAddItem_Click);
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Home.aspx");
            }
            //div1.Visible = true;
        }
        private void lbAddItem_Click(object sender, EventArgs e)
        {
            try
            {
                fms.AddMenus();
                ddlMenus.DataSource = fms.ds.Tables[0];
                ddlMenus.DataTextField = "Meals";
                ddlMenus.DataValueField = "Code";
                ddlMenus.DataBind();
                //this.BindTable();
                //ddlMenus.AutoPostBack = true;
                ModalPopupExtender1.Show();
                if (ddlMenus != null)
                {
                    fms.AddItems(Convert.ToString(ddlMenus.SelectedIndex));
                    ddlItems.DataSource = fms.ds;
                    ddlItems.DataTextField = "ItemName";
                    ddlItems.DataValueField = "TimeCode";
                    ddlItems.DataBind();

                    ModalPopupExtender1.Show();
                    // this.BindTable();
                    if (ddlItems.Text == "")
                    {
                        ddlItems.Items.Add("No Items");

                    }
                    if (ddlItems.Text == "No Items")
                    {
                        btnAdd.Enabled = false;
                        ddlItems.Enabled = false;
                    }
                    else
                    {
                        ddlItems.Enabled = true;
                        btnAdd.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "", "alert('" + ex.Message + "')", true);
            }
        }

        private void BindTable()
        {
            if (ddlMenus != null)
            {
                foreach (ListItem item in ddlMenus.Items)
                {
                    item.Attributes["title"] = item.Value;

                }
            }
        }

        private void lbLogout_Click(object sender, EventArgs e)
        {

            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
        public void CheckLastCooked()
        {
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("select LastCookedAmount,LastWastedAmount from tblProduct", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    LastWasted = ds.Tables[0].Rows[0][0].ToString();
                    LastWasted = ds.Tables[0].Rows[0][1].ToString();
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "", "alert('" + ex.Message + "')", true);
            }
        }
        public void tblMenu()
        {
            while (true)
            {

            }
        }
        protected void ddlMenus_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                fms.AddItems(Convert.ToString(ddlMenus.SelectedIndex));
                ddlItems.DataSource = fms.ds;
                ddlItems.DataTextField = "ItemName";
                ddlItems.DataValueField = "TimeCode";
                ddlItems.DataBind();

                ModalPopupExtender1.Show();
                this.BindTable();
                if (ddlItems.Text == "")
                {
                    ddlItems.Items.Add("No Items");

                }
                if (ddlItems.Text == "No Items")
                {
                    btnAdd.Enabled = false;
                    ddlItems.Enabled = false;
                }
                else
                {
                    ddlItems.Enabled = true;
                    btnAdd.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "", "alert('" + ex.Message + "')", true);
            }
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string ddl = ddlItems.SelectedItem.Text;
                fms.AddGrid(Convert.ToString(ddlMenus.SelectedIndex), ddlItems.SelectedItem.Text);
                Session["activate"] = "Successfully Added!!";
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "", "alert('Successfully Added!!')", true);
                ModalPopupExtender1.Hide();

                //return;
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "", "alert('" + ex.Message + "!!')", true);
            }
            finally
            {
                Response.Redirect("UserHome.aspx");
            }
        }
    }
}