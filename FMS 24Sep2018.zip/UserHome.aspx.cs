﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace FMS
{
    public partial class UserHome : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        private bool iBtnPrev = false;
        private bool iBtnNext = false;
        BLL objBll = new BLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
                lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");


            }
        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {

        }

        protected void UpdateTimer_Tick(object sender, EventArgs e)
        {

        }

        protected void Panel_Click()
        {
            if (iBtnNext)
            {
                int lblAmt = Convert.ToInt32(lblAmountCook.Text.Trim());

                lblAmountCook.Text = Convert.ToString(lblAmt + 1);
                ibPrev.Enabled = true;
            }
            else if (iBtnPrev)
            {
                int lblAmt = Convert.ToInt32(lblAmountCook.Text.Trim());
                if (lblAmt > 1)
                {
                    lblAmountCook.Text = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    ibPrev.Enabled = false;
                }
            }

        }
        protected void ibNext_Click(object sender, ImageClickEventArgs e)
        {

            iBtnNext = true;
            Panel_Click();
        }

        protected void ibPrev_Click(object sender, ImageClickEventArgs e)
        {
            iBtnPrev = true;
            Panel_Click();
        }
    }
}
