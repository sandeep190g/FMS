﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace FMS
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        BLL objBll = new BLL();
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        string LastCooked = "";
        string LastWasted = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            lbLogout.ServerClick += new EventHandler(lbLogout_Click);
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Home.aspx");
            }

        }
        private void lbLogout_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
        public void CheckLastCooked()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select LastCookedAmount,LastWastedAmount from tblProduct", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                LastWasted = ds.Tables[0].Rows[0][0].ToString();
                LastWasted = ds.Tables[0].Rows[0][1].ToString();
            }
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtStoreID.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Store ID')</script>");
            else if (txtItemName.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Item Name')</script>");
            else if (txtExpTime.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Exp Time')</script>");
            else if (txtDuration.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Duration')</script>");
            CheckLastCooked();
            BAL obJBE = new BAL();
            obJBE.UserId = txtStoreID.Text.Trim();
            obJBE.IName = txtItemName.Text.Trim();
            obJBE.ExpTime = txtExpTime.Text.Trim();
            obJBE.Name = txtDuration.Text.Trim();
            obJBE.QtyHand = LastCooked;
            obJBE.Wasted = LastWasted;
            DataSet ds = new DataSet();
            ds = objBll.InsertItem(obJBE);
            this.Page.ClientScript.RegisterStartupScript(this.GetType(), "", "alert('Item Added!!')", true);
            txtStoreID.Text = "";
            txtItemName.Text = "";
            txtExpTime.Text = "";
            txtDuration.Text = "";

        }
    }
}