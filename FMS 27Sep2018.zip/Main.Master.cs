﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblTime.Text = TimeZone.CurrentTimeZone.DaylightName;
            }

            lbLogout.ServerClick += new EventHandler(lbLogout_Click);
            if (Session["UserId"] != null)
            {
                lbAccount.Text = Session["Name"].ToString();
                //string role = Session["Role"].ToString();
                //if (role.Trim() == "Admin")
                //{
                //    aFood.Visible = true;
                //    aCategory.Visible = true;
                //    aStock.Visible = true;
                //    aSale.Visible = true;
                //    aCoupon.Visible = true;
                //}
                //else if (role.Trim() == "User")
                //{
                //    aAddItem.Visible = true;
                //    aWaste.Visible = true;
                //    aCook.Visible = true;
                //    //aAddItem.Visible = true;
                //}
                //else
                //{
                //    Response.Write("<script>alert('Sorry! You are not a valid user to access this application or your account is disabled')</script>");
                //    return;
                //}
            }
            else
            {
                Response.Redirect("~/Home.aspx");
            }
        }
        private void lbLogout_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}