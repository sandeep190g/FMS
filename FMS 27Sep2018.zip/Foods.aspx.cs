﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace FMS
{
    public partial class Foods : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        BLL objBll = new BLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.Dash();
            }
        }
        public void Dash()
        {
            con.Open();
            string strProduct = "select * from tblProduct;";
            SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            //Label lblItemName = (Label)row.FindControl("lblItemName");
            TextBox txtStoreID = (TextBox)row.FindControl("txtStoreID");
            TextBox txtItemName = (TextBox)row.FindControl("txtItemName");
            TextBox txtUPC = (TextBox)row.FindControl("txtUPC");
            TextBox txtTimeCode = (TextBox)row.FindControl("txtTimeCode");
            TextBox txtExpTime = (TextBox)row.FindControl("txtExpTime");
            TextBox txtCookDuration = (TextBox)row.FindControl("txtCookDuration");
            TextBox txtLastAmount = (TextBox)row.FindControl("txtLastAmount");
            TextBox txtLastWasted = (TextBox)row.FindControl("txtLastWasted");
            FileUpload fileVideo = (FileUpload)row.FindControl("fileVideo");
            FileUpload fileImage = (FileUpload)row.FindControl("fileImage");
            TextBox txtStepUrl = (TextBox)row.FindControl("txtStepUrl");
            Image img1 = (Image)row.FindControl("img1");


            Label lblItemID = (Label)row.FindControl("lblItemID");
            Label lblStoreID = (Label)row.FindControl("lblStoreID");
            Label lblItemName = (Label)row.FindControl("lblItemName");
            Label lblUPC = (Label)row.FindControl("lblUPC");
            Label lblTimeCode = (Label)row.FindControl("lblTimeCode");
            Label lblExpTime = (Label)row.FindControl("lblExpTime");
            Label lblCookDuration = (Label)row.FindControl("lblCookDuration");
            Label lblLastAmount = (Label)row.FindControl("lblLastAmount");
            Label lblLastWasted = (Label)row.FindControl("lblLastWasted");
            Label lblVideoUrl = (Label)row.FindControl("lblVideoUrl");
            Label lblStepUrl = (Label)row.FindControl("lblStepUrl");


            //Label lblItemID = (Label)row.FindControl("lblItemID");
            //Label lblItemID = (Label)row.FindControl("lblItemID");
            //Label lblItemID = (Label)row.FindControl("lblItemID");
            //Label lblItemID = (Label)row.FindControl("lblItemID");

            Button btnAdd = (Button)row.FindControl("btnAdd");
            Button btnEdit = (Button)row.FindControl("btnEdit");

            if (e.CommandName == "Add")
            {
                string strpath = "~/Pictures/" + fileImage.PostedFile.FileName;
                fileImage.SaveAs(Server.MapPath(strpath));
                BAL obJBE = new BAL();
                obJBE.ImageUrl = strpath;
                obJBE.StorID = txtStoreID.Text.Trim();
                obJBE.IName = txtItemName.Text.Trim();
                obJBE.UPC = txtUPC.Text.Trim();
                obJBE.TimeCode = txtTimeCode.Text.Trim();
                obJBE.ExpTime = txtExpTime.Text.Trim();
                obJBE.Loc = txtCookDuration.Text.Trim();
                obJBE.QtyHand = txtLastAmount.Text.Trim();
                obJBE.Wasted = txtLastWasted.Text.Trim();
                obJBE.VideoUrl = fileVideo.PostedFile.FileName;
                obJBE.StepUrl = txtStepUrl.Text.Trim();
                DataSet ds1 = new DataSet();
                ds1 = objBll.CookedItem(obJBE);
                Response.Write("<script>alert('Successfully Added!!')</script>");
                this.Dash();
                strpath = "";
                txtStoreID.Text = "";
                txtItemName.Text = "";
                txtUPC.Text = "";
                txtTimeCode.Text = "";
                txtExpTime.Text = "";
                txtCookDuration.Text = "";
                txtLastAmount.Text = "";
                txtLastWasted.Text = "";
                txtStepUrl.Text = "";
                img1.ImageUrl = null;
                return;

            }
            else if (e.CommandName == "Update")
            {
                lblID.Text = lblItemID.Text;
                txtItemName1.Text = lblItemName.Text;
                txtStoreID1.Text = lblStoreID.Text;
                txtUPC1.Text = lblUPC.Text;
                txtTimeCode1.Text = lblTimeCode.Text;
                txtExpTime1.Text = lblExpTime.Text;
                txtCookDuration1.Text = lblCookDuration.Text;
                txtLastAmount1.Text = lblLastAmount.Text;
                txtLastWasted1.Text = lblLastWasted.Text;
                txtStepUrl1.Text = lblStepUrl.Text;
                //fileVideo1.FileName = fileVideo.FileName;


                ModalPopupExtender1.Show();
            }

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string strpathImg = "";
                string strpathVid = "";
                if (fileImage1.FileName != "".Trim())
                {
                    strpathImg = "~/Pictures/" + fileImage1.PostedFile.FileName;
                    fileImage1.SaveAs(Server.MapPath(strpathImg));
                    //fileImage1.SaveAs(strpathImg);
                }
                if (fileVideo1.FileName != "".Trim())
                {
                    strpathVid = "D:/Vid/" + fileVideo1.PostedFile.FileName;
                    fileVideo1.SaveAs(strpathVid);
                }
                con.Open();
                string query = "update tblProduct set StoreID=@Store ,ItemName=@ItemName,UPC=@UPC,TimeCode=@TimeCode,Expirationtime=@ExpTime,Cookduration=@Dura,LastCookedAmount=@LastCooked,LastWastedAmount=@LastWasted,ImageUrl=@ImageUrl,VideoUrl=@VideoUrl,StepsUrl=@StepUrl where ItemID='" + lblID.Text + "';";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Store", txtStoreID1.Text.Trim());
                cmd.Parameters.AddWithValue("@ItemName", txtItemName1.Text.Trim());
                cmd.Parameters.AddWithValue("@UPC", txtUPC1.Text.Trim());
                cmd.Parameters.AddWithValue("@TimeCode", txtTimeCode1.Text.Trim());
                cmd.Parameters.AddWithValue("@ExpTime", txtExpTime1.Text.Trim());
                cmd.Parameters.AddWithValue("@Dura", txtCookDuration1.Text.Trim());
                cmd.Parameters.AddWithValue("@LastCooked", txtLastAmount1.Text.Trim());
                cmd.Parameters.AddWithValue("@LastWasted", txtLastWasted1.Text.Trim());
                cmd.Parameters.AddWithValue("@ImageUrl", strpathImg.ToString());
                cmd.Parameters.AddWithValue("@VideoUrl", strpathVid.ToString());
                cmd.Parameters.AddWithValue("@StepUrl", txtStepUrl1.Text.Trim());


                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                dataAdapter.Fill(ds);
                Response.Write("<script>alert('Successfully Updated!!')</script>");
                this.Dash();
                con.Close();
                return;
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('An Error-" + ex.Message + "')</script>");
                return;
            }
        }
    }
}