﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace FMS
{
    public partial class UserHome : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        private bool iBtnPrev = false;
        private bool iBtnNext = false;
        public string amount = "";
        public int intCook;

        BLL objBll = new BLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            intCook = Convert.ToInt32(lblCook.Text.Trim());
            if (!IsPostBack)
            {
                lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
                lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
                Dash();
            }
        }
        public void Dash()
        {
            con.Open();
            string strProduct = "select convert(datetime, GETDATE()) +convert(datetime, Expirationtime) as Time,*from tblProduct; ";
            SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {

        }

        protected void UpdateTimer_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        protected void Panel_Click(string amt, ImageButton button)
        {
            if (iBtnNext)
            {
                int lblAmt = Convert.ToInt32(amt.Trim());

                amt = Convert.ToString(lblAmt + 1);
                button.Enabled = true;
            }
            else if (iBtnPrev)
            {
                int lblAmt = Convert.ToInt32(amt.Trim());
                if (lblAmt > 1)
                {
                    amt = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    button.Enabled = false;
                }
            }
            amount = Convert.ToString(amt);
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            Label lblLastAmount = (Label)row.FindControl("lblLastAmount");
            //Label lblLastAmount = (Label)row.FindControl("lblLastAmount");
            ImageButton ibNext = (ImageButton)row.FindControl("ibNext");
            ImageButton ibPrev = (ImageButton)row.FindControl("ibPrev");
            Button btnCookSelect = (Button)row.FindControl("btnCookSelect");

            if (e.CommandName == "next")
            {
                iBtnNext = true;
                Panel_Click(lblLastAmount.Text.Trim(), ibNext);
                lblLastAmount.Text = amount;
                ibPrev.Enabled = true;
            }
            else if (e.CommandName == "prev")
            {
                iBtnPrev = true;
                Panel_Click(lblLastAmount.Text.Trim(), ibPrev);
                lblLastAmount.Text = amount;
            }
            else if (e.CommandName == "cook")
            {
                intCook = intCook + 1;
                lblCook.Text = intCook.ToString();
                btnCookSelect.Enabled = false;
                btnCookSelect.CssClass = "btn-Primary";
            }
        }
    }
}
