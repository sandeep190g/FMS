﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Home : System.Web.UI.Page
    {
        BLL objBll = new BLL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            BAL obJBE = new BAL();
            obJBE.UserId = txtUserName.Text.Trim();
            obJBE.Password = txtPassword.Text.Trim();
            DataSet ds = new DataSet();
            ds = objBll.UserLogin(obJBE);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["UserId"] = ds.Tables[0].Rows[0][0].ToString();
                String name = null;
                String Uid = null;
                String Psw = null;
                String Role = null;
                String Loc = null;
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][1].ToString()))
                {
                    Uid = ds.Tables[0].Rows[0][1].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][2].ToString()))
                {
                    Psw = ds.Tables[0].Rows[0][2].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][3].ToString()))
                {
                    name = ds.Tables[0].Rows[0][3].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][4].ToString()))
                {
                    Role = ds.Tables[0].Rows[0][4].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][5].ToString()))
                {
                    Loc = ds.Tables[0].Rows[0][5].ToString();
                }
                Session["Name"] = name;
                Session["UserID"] = Uid;
                Session["Psw"] = Psw;
                Session["Role"] = Role;
                Session["Loc"] = Loc;
                Session["UserID"] = Uid;
                Response.Redirect("~/UserHome.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid Credential')</script>");
            }
        }
    }
}