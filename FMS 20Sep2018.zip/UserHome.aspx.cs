﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class UserHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
                lblTime.Text = DateTime.Now.ToString("hh:mm tt");
                string time = DateTime.Now.ToString("hh:mm tt");
            }
        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {

            DateTime timMorn = Convert.ToDateTime("04:01 AM");
            TimeSpan n = timMorn.TimeOfDay;
            DateTime dateTime = Convert.ToDateTime(lblTime.Text);
            TimeSpan ts1 = dateTime.TimeOfDay;
            if (n >= ts1)
            {
                ddlLunch.SelectedIndex = 0;
            }
            else if (n >= ts1)
            {
                ddlLunch.SelectedIndex = 1;
            }
            else if (n >= ts1)
            {
                ddlLunch.SelectedIndex = 2;
            }




        }
    }
}
