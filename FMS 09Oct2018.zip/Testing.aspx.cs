﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Testing : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                System.Web.UI.Timer timeoutTimer = new System.Web.UI.Timer();
                timeoutTimer.ID = "timeouttimer";
                timeoutTimer.Interval = 1000;
                timeoutTimer.Tick += new EventHandler<EventArgs>(timeoutTimer_Tick);


                UpdatePanel timerUpdatePanel = new UpdatePanel();
                timerUpdatePanel.ContentTemplateContainer.Controls.Add(timeoutTimer);


                ScriptManager.GetCurrent(this.Page).RegisterAsyncPostBackControl(timeoutTimer);


                this.Page.Form.Controls.Add(timerUpdatePanel); base.OnInit(e);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
        protected void timeoutTimer_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("Hello Testing" + DateTime.Now.ToString("hh:mm:ss"));
        }
    }
}