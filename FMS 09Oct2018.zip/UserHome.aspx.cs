﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace FMS
{
    public partial class UserHome : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        private bool iBtnPrev = false;
        private bool iBtnNext = false;
        public string amount = "";
        public int intCook;

        BLL objBll = new BLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            intCook = Convert.ToInt32(lblCook.Text.Trim());
            if (!IsPostBack)
            {
                lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
                lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
                timeStatus();
                Dash();
                truncateData();
            }
        }
        public void timeStatus()
        {
            TimeSpan timeMorn = new TimeSpan(4, 1, 1);
            TimeSpan endMorn = new TimeSpan(11, 59, 1);
            TimeSpan timeNoon = new TimeSpan(12, 1, 1);
            TimeSpan endNoon = new TimeSpan(16, 59, 1);
            TimeSpan timeEve = new TimeSpan(17, 1, 1);
            TimeSpan endEve = new TimeSpan(23, 59, 1);

            TimeSpan now = DateTime.Now.TimeOfDay;

            if ((now > timeMorn) && (now < endMorn))
            {
                ddlLunch.SelectedItem.Text = "  Breakfast  ";
            }
            else if ((now > timeNoon) && (now < endNoon))
            {
                ddlLunch.SelectedItem.Text = "   Lunch    ";
            }
            else if ((now > timeEve) && (now < endEve))
            {
                ddlLunch.SelectedItem.Text = "   Dinner  ";
            }
        }
        public void Dash()
        {
            try
            {
                con.Open();
                // string strProduct = "select convert(datetime, GETDATE()) +convert(datetime, Expirationtime) as Time,* from tblProduct where Status=1; ";
                string strProduct = "select * from tblProduct where Status=1; ";
                SqlDataAdapter da = new SqlDataAdapter(strProduct, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }
        public void createTable()
        {
            try
            {
                string tbName = "tblTempCook";
                con.Open();
                string query = "create table [" + tbName + "] (ItemID int,ItemName varchar(50),PullTime time(0),wasted int,qtyOnHand varchar(50))";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            finally
            {
                con.Close();
            }
        }
        public void truncateData()
        {
            try
            {
                con.Open();
                string filename = "tblTempCook";
                string query = "truncate table [" + filename + "]";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            finally
            {
                con.Close();
            }
        }
        public void DataInsert(string ItemID, string ItemName, DateTime pullTime, int wasted, int qty)
        {
            try
            {
                con.Open();
                TimeSpan timeSpan = pullTime.TimeOfDay;
                string filename = "tblTempCook";
                string query = "insert into [" + filename + "] (ItemID,ItemName,PullTime,wasted,qtyOnHand) values (@IID,@IName,@Ptime,@wst,@qty)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IID", ItemID);
                cmd.Parameters.AddWithValue("@IName", ItemName);
                cmd.Parameters.AddWithValue("@Ptime", timeSpan);
                cmd.Parameters.AddWithValue("@wst", wasted);
                cmd.Parameters.AddWithValue("@qty", qty);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            finally
            {
                con.Close();
            }
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {

        }
        int abc;
        //int i;
        int Decrease;
        int dec;
        protected void UpdateTimer_Tick(object sender, EventArgs e)
        {
            //i++;

            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
            if (Session["Left"] != null)
            {
                abc = Convert.ToInt32(Session["Left"].ToString());
                Decrease = abc - 1000;
                Session["Left"] = Decrease;
                if (Session["timeout"] == null)
                {
                    DateTime s = DateTime.Now.AddSeconds(10);
                    Session["time"] = s;
                }
                if (Session["timeout"] != null)
                {
                    if (0 > DateTime.Compare(DateTime.Now, DateTime.Parse(Session["timeout"].ToString())))
                    {
                        //lblAlert.Text = "Time Left: " + timeSpan;
                        //lblAlert.Text = string.Format("Time Left: 00:{00}:{1}", ((Int32)DateTime.Parse(Session["timeout"].ToString()).Subtract(DateTime.Now).TotalMinutes).ToString(), ((Int32)DateTime.Parse(Session["timeout"].ToString()).Subtract(DateTime.Now).Seconds).ToString());
                        var timeSpan = TimeSpan.FromMilliseconds(Decrease);
                        int index = Convert.ToInt32(Session["rIndex"].ToString());
                        GridViewRow row1 = GridView1.Rows[index];
                        foreach (GridViewRow row in GridView1.Rows)
                        {

                            Label lblStartCooking = GridView1.Rows[index].Cells[0].Controls[0].FindControl("lblStartCooking") as Label;

                            lblStartCooking.Text = timeSpan.ToString();
                        }
                    }
                }
                else
                {
                    lblAlert.Text = "No Alert......";
                }
            }
        }



        protected void Panel_Click(string amt, ImageButton button)
        {
            if (iBtnNext)
            {
                int lblAmt = Convert.ToInt32(amt.Trim());

                amt = Convert.ToString(lblAmt + 1);
                button.Enabled = true;
            }
            else if (iBtnPrev)
            {
                int lblAmt = Convert.ToInt32(amt.Trim());
                if (lblAmt > 1)
                {
                    amt = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    button.Enabled = false;
                }
            }
            amount = Convert.ToString(amt);
        }
        public string plTime = "";
        public string batchNo = "";
        //public int timeMsSinceMidnight = 0;
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            Label lblLastAmount = (Label)row.FindControl("lblLastAmount");
            Label lblItemID = (Label)row.FindControl("lblItemID");
            Label lblItemName = (Label)row.FindControl("lblItemName");
            Label lblExpTime = (Label)row.FindControl("lblExpTime");
            Label lblLastCooked = (Label)row.FindControl("lblLastCooked");
            Label lblWasted = (Label)row.FindControl("lblWasted");
            Label lblStartCooking = (Label)row.FindControl("lblStartCooking");
            //Label lblLastAmount = (Label)row.FindControl("lblLastAmount");
            ImageButton ibNext = (ImageButton)row.FindControl("ibNext");
            ImageButton ibPrev = (ImageButton)row.FindControl("ibPrev");
            Button btnCookSelect = (Button)row.FindControl("btnCookSelect");

            if (e.CommandName == "next")
            {
                iBtnNext = true;
                Panel_Click(lblLastAmount.Text.Trim(), ibNext);
                lblLastAmount.Text = amount;
                ibPrev.Enabled = true;
            }
            else if (e.CommandName == "prev")
            {
                iBtnPrev = true;
                Panel_Click(lblLastAmount.Text.Trim(), ibPrev);
                lblLastAmount.Text = amount;
            }
            else if (e.CommandName == "cook")
            {
                intCook = intCook + 1;
                lblCook.Text = intCook.ToString();
                string filename;
                filename = "tblTempCook";
                try
                {
                    int count = GridView1.Rows.Count;
                    int RowIndex = row.RowIndex;
                    Session["rIndex"] = RowIndex;

                    


                    con.Open();
                    string query = "select * from FMS.INFORMATION_SCHEMA.TABLES where TABLE_NAME='" + filename + "'";
                    string queryExp = "select Expirationtime,BatchNo from tblProduct where ItemID='" + lblItemID.Text.Trim() + "'";
                    SqlCommand cmd = new SqlCommand(query + queryExp, con);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    if (ds.Tables[0].Rows.Count < 1)
                    {
                        con.Close();
                        createTable();
                        cmd.Dispose();
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        plTime = ds.Tables[1].Rows[0][0].ToString();
                        batchNo = ds.Tables[1].Rows[0][1].ToString();

                        DateTime dt = Convert.ToDateTime(plTime);
                        int timeMsSinceMidnight = (int)dt.TimeOfDay.TotalMilliseconds;
                        Session["Left"] = timeMsSinceMidnight;
                        int nowTime = (int)DateTime.Now.TimeOfDay.TotalMilliseconds;
                        Session["cur"] = nowTime;
                        DateTime str = DateTime.Now.AddMinutes(timeMsSinceMidnight);
                        Session["timeout"] = str.ToString();
                        con.Close();
                        lblStartCooking.Text = plTime;


                        DataInsert(lblItemID.Text, lblItemName.Text, Convert.ToDateTime(plTime), Convert.ToInt32(lblWasted.Text), Convert.ToInt32(lblLastCooked.Text));

                        lblExpTime.Visible = true;
                        lblExpTime.Text += batchNo + "," + plTime + "</br>";
                        Session["s1"] = lblExpTime.Text;
                        lblStartCooking.Visible = true;
                        //lblStartCooking.Text = DateTime.Now.ToString("hh:mm:ss");
                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ex.Message + "')", true);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public void tblCooking(string query)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (SqlException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ex.Message + "')", true);
            }
            finally
            {
                con.Close();
            }
        }
        protected void btnCook_Click(object sender, EventArgs e)
        {
            try
            {

                con.Open();
                string query = "select * from tblTempCook";
                SqlCommand cmd = new SqlCommand(query, con);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string name = ds.Tables[0].Rows[i][1].ToString();
                        DateTime pullTime = Convert.ToDateTime(ds.Tables[0].Rows[i][2].ToString());
                        TimeSpan exp = pullTime.TimeOfDay;
                        int wst = Convert.ToInt32(ds.Tables[0].Rows[i][3].ToString());

                        int qty = Convert.ToInt32(ds.Tables[0].Rows[i][4].ToString());
                        con.Close();
                        string queryCook = "insert into tblCooking (ItemName,QtyOnHand,WastedToday,AmountCook,ExpTime,CookedTime) values('" + name + "','" + qty + "','" + wst + "','" + qty + "','" + exp + "',TRY_CONVERT(datetime, '" + DateTime.Now + "', 121))";
                        tblCooking(queryCook);
                        string queryLog = "insert into tblCookLog (ItemName,UserID,ExpTime,AmountCooked,CookedTime) values('" + name + "','" + Session["UserId"].ToString() + "','" + exp + "','" + qty + "',TRY_CONVERT(datetime, '" + DateTime.Now + "', 120))";
                        tblCooking(queryLog);

                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ds.Tables[0].Rows.Count + " Items find')", true);
                    }
                }
                else
                {
                    con.Close();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ds.Tables[0].Rows.Count + " Items find')", true);
                    return;
                }
                truncateData();
                Response.Write("<script>alert('" + ds.Tables[0].Rows.Count + " Items find')</script>");
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ds.Tables[0].Rows.Count + " Selected Item Cooked')", true);
            }
            catch (SqlException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + ex.Message + "')", true);
            }
            finally
            {
                con.Close();
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = GridView1.SelectedRow.Cells[2].Text;
        }
    }
}
