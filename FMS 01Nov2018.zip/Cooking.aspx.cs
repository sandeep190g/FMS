﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FMS.Classes;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;




namespace FMS
{
    public partial class Cooking : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        FMSClass fmsClass = new FMSClass();
        public int timeCode;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                timeStatus();
                fmsClass.RefGrid(timeCode);
                createDesign(fmsClass.msg);
            }
        }
        public void Dash(string msg)
        {
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(msg, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                //gvCooking.DataSource = ds;
                //gvCooking.DataBind();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }


        public void createDesign(string msg)
        {

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(msg, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            //gvCooking.DataSource = ds;
            //gvCooking.DataBind();

            //con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblHi.Text += "<div class='row'>";
                lblHi.Text += "<div class='col-md-12'>";
                lblHi.Text += "<div class='x_panel'>";
                lblHi.Text += "<div class='x_title'>";
                lblHi.Text += "<h2>Cooking Foods!</h2>";
                lblHi.Text += "<ul class='nav navbar-right panel_toolbox'>";
                lblHi.Text += "<li><a class='collapse-link'><i class='fa fa-chevron-up'></i></a></li>";
                lblHi.Text += "<li class='dropdown'>";
                lblHi.Text += "<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-expanded='false'><i class='fa fa-wrench'></i></a>";
                lblHi.Text += "<ul class='dropdown-menu' role='menu'>";
                lblHi.Text += "<li><a href='#'>Settings 1</a></li><li><a href='#'>Settings 2</a></li></ul></li>";
                lblHi.Text += "<li><a class='close-link'><i class='fa fa-close'></i></a></li></ul>";
                lblHi.Text += "<div class='clearfix'></div></div><div class='x_content'>";


                lblHi.Text += "<p>Click on cook button and cooking will be started..</p>";
                lblHi.Text += " <table class='table table-striped projects' border='1' style='border:2px solid #abb3e5; text-align:center'> <thead><tr>";
                lblHi.Text += "<th style='width:10%; text-align:center'>Product Name</th><th style='text-align:center'>Picture</th>";
                lblHi.Text += "<th style='text-align:center'>Pull Time</th><th style='text-align:center'>Qty on hand</th>";
                lblHi.Text += "<th style='text-align:center'>Cooked Amt</th><th style='width:20%; text-align:center'>Product Process</th>";
                lblHi.Text += "<th style='text-align:center'>Status</th><th style='text-align:center'>Action</th></tr> </thead>";

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string pID = ds.Tables[0].Rows[i]["ItemID"].ToString();
                    string pName = ds.Tables[0].Rows[i]["ItemName"].ToString();
                    string iURL = ds.Tables[0].Rows[i]["ImageUrl"].ToString().Replace("~", "");
                    string pullTime = ds.Tables[0].Rows[i]["Expirationtime"].ToString() + "&nbsp;&nbsp" + DateTime.Now.ToString("tt");
                    string qtyHand = ds.Tables[0].Rows[i]["LastCookedAmount"].ToString();
                    string forCasted = ds.Tables[0].Rows[i]["LastCookedAmount"].ToString();




                    lblHi.Text += "<tbody><tr><td>" + pName + "</br><a href='#'><small align='center' style='color:blue'>Steps</small></a></td>";
                    lblHi.Text += "<td><ul class='list-inline'><li><img src='" + iURL + "' class='avatar' alt='Avatar'></li></ul></td>";
                    lblHi.Text += "<td>" + pullTime + "</td><td>" + qtyHand + "</td><td>" + forCasted + "</td>";
                    lblHi.Text += "<td class='project_progress'><div class='progress progress_sm'><div class='progress-bar bg-green' role='progressbar' data-transitiongoal='50'></div>";
                    lblHi.Text += "</div><small>50% Complete</small><td><button type='button' class='btn btn-success btn-xs'>cooking</button></td>";
                    lblHi.Text += "<td><a href='#' class='btn btn-success'><i class='fa fa-clock-o'></i>&nbsp;&nbsp;&nbsp;Cook </a></td></tr>";
                }
                lblHi.Text += "</tbody></table></div></div></div></div>";
                lblHi.Text += "<h5 style='float:right;'>Thankyou......</h5>";
            }
        }
        public void timeStatus()
        {
            TimeSpan timeMorn = new TimeSpan(4, 1, 1);
            TimeSpan endMorn = new TimeSpan(11, 59, 1);
            TimeSpan timeNoon = new TimeSpan(12, 1, 1);
            TimeSpan endNoon = new TimeSpan(16, 59, 1);
            TimeSpan timeEve = new TimeSpan(17, 1, 1);
            TimeSpan endEve = new TimeSpan(23, 59, 1);

            TimeSpan now = DateTime.Now.TimeOfDay;

            if ((now > timeMorn) && (now < endMorn))
            {
                timeCode = 1;
            }
            else if ((now > timeNoon) && (now < endNoon))
            {
                timeCode = 2;
            }
            else if ((now > timeEve) && (now < endEve))
            {
                timeCode = 3;
            }
        }


    }
}