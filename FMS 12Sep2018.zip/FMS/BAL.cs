﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FMS
{
    public class BAL
    {


        private string userId;
        private string password;
        private string name;
        private string role;
        private string loc;


        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string UserId
        {
            get { return userId; }
            set { userId = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Role
        {
            get { return role; }
            set { role = value; }
        }
        public string Loc
        {
            get { return loc; }
            set { loc = value; }
        }
    }
}