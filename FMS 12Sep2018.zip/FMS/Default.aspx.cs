﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FMS
{
    public partial class Default : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dvDashBoard.Visible = true;
                lblTime.Text = System.DateTime.Now.ToString("hh:mm tt");
                this.DashBoard();

            }
        }
        public void DashBoard()
        {
            con.Open();
            string strProduct = "select count(*) from tblProducts where Isavailable=1;";
            string strPaid = "select count(*) from tblProducts where Sale=1;";
            string strStore = "select count(*) from tblStores;";
            string strUsers = "select count(*) from UserLogin where Status=1;";
            string strWasted = "select count(*) from tblProducts where IsWasted=1;";
            SqlDataAdapter da = new SqlDataAdapter(strProduct + strPaid + strStore + strUsers + strWasted, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables.Count > 0)
            {
                lblProcs.Text = ds.Tables[0].Rows[0][0].ToString();
                lblPaid.Text = ds.Tables[1].Rows[0][0].ToString();
                lblStores.Text = ds.Tables[2].Rows[0][0].ToString();
                lblUsers.Text = ds.Tables[3].Rows[0][0].ToString();
                lblSoldOut.Text = ds.Tables[4].Rows[0][0].ToString();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "", "alert('Table Not Found')", true);
            }
        }

        protected void btnTablet_Click(object sender, EventArgs e)
        {
            dvDashBoard.Visible = false;
            dvTablet.Visible = true;
        }
    }
}