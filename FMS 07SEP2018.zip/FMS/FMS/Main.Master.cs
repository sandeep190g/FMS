﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbLogout.ServerClick += new EventHandler(lbLogout_Click);
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Home.aspx");
            }
            else
            {
                lbAccount.Text = Session["Name"].ToString();
            }
        }

        private void lbLogout_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
    }
}