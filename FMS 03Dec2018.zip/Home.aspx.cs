﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class Home : System.Web.UI.Page
    {
        BLL objBll = new BLL();
        protected void Page_Load(object sender, EventArgs e)
        {




            string cdate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt");
            DateTime d1 = Convert.ToDateTime(cdate);
            string exDate = "28/11/2018 23:10:10";
            DateTime d2 = Convert.ToDateTime(exDate);
            DateTime ds = d2.Date;
            var resss = d2.TimeOfDay;

            DateTime ts1 = ds + resss;



            DateTime dss = d1 + d2.TimeOfDay;
            var res = d1.Hour;
            var res2 = d1.Minute;

            var dee = d1.AddHours(res);
            var dm = d1.AddMinutes(res2);



            txtUser.Focus();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            BAL obJBE = new BAL();
            obJBE.UserId = txtUser.Text.Trim();
            obJBE.Password = txtPassword.Text.Trim();
            DataSet ds = new DataSet();
            ds = objBll.UserLogin(obJBE);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["UserId"] = ds.Tables[0].Rows[0][0].ToString();
                String name = null;
                String Uid = null;
                String Psw = null;
                String Role = null;
                String Loc = null;
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][1].ToString()))
                {
                    Uid = ds.Tables[0].Rows[0][1].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][2].ToString()))
                {
                    Psw = ds.Tables[0].Rows[0][2].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][3].ToString()))
                {
                    name = ds.Tables[0].Rows[0][3].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][4].ToString()))
                {
                    Role = ds.Tables[0].Rows[0][4].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][5].ToString()))
                {
                    Loc = ds.Tables[0].Rows[0][5].ToString();
                }
                Session["Name"] = name;
                Session["UserID"] = Uid;
                Session["Psw"] = Psw;
                Session["Role"] = Role.Trim();
                Session["Loc"] = Loc;
                Session["UserID"] = Uid;
                if (Role.Trim() == "Admin")
                    Response.Redirect("~/Default.aspx");
                else
                    Response.Redirect("~/UserHome.aspx");


            }
            else
            {
                Response.Write("<script>alert('Invalid Credential')</script>");
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            BAL obJBE = new BAL();
            obJBE.UserId = txtUser.Text.Trim();
            obJBE.Password = txtPassword.Text.Trim();
            DataSet ds = new DataSet();
            ds = objBll.UserLogin(obJBE);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["UserId"] = ds.Tables[0].Rows[0][0].ToString();
                String name = null;
                String Uid = null;
                String Psw = null;
                String Role = null;
                String Loc = null;
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][1].ToString()))
                {
                    Uid = ds.Tables[0].Rows[0][1].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][2].ToString()))
                {
                    Psw = ds.Tables[0].Rows[0][2].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][3].ToString()))
                {
                    name = ds.Tables[0].Rows[0][3].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][4].ToString()))
                {
                    Role = ds.Tables[0].Rows[0][4].ToString();
                }
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0][5].ToString()))
                {
                    Loc = ds.Tables[0].Rows[0][5].ToString();
                }
                Session["Name"] = name;
                Session["UserID"] = Uid;
                Session["Psw"] = Psw;
                Session["Role"] = Role.Trim();
                Session["Loc"] = Loc;
                Session["UserID"] = Uid;
                if (Role.Trim() == "Admin")
                    Response.Redirect("~/Default.aspx");
                else
                    Response.Redirect("~/Cooking.aspx");


            }
            else
            {
                Response.Write("<script>alert('Invalid Credential')</script>");
            }
        }
    }
}