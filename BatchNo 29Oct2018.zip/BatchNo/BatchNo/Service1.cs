﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
namespace BatchNo
{
    public partial class Service1 : ServiceBase
    {
        private Timer timer = null;
        public Service1()
        {
            InitializeComponent();
        }

        public void ondebud()
        {
            timer_tick(null, null);
            //OnStart(null);
        }
        protected override void OnStart(string[] args)
        {
            //Logs.SendMessage("Timer is set for 10 seconds..");
            timer = new Timer();
            this.timer.Interval = 1000;
            this.timer.Elapsed += new ElapsedEventHandler(this.timer_tick);
            this.timer.Enabled = true;
            //timer_tick(null, null);
        }
        private void timer_tick(object sender, EventArgs e)
        {
            string date = System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
            bool sbc = false;
            //Logs.SendMessage("Some programs is running in background.....");
            // after condition..
            string dt = DateTime.Now.ToString("hh:mm:ss tt");
            //string cDate = "12:00:01 AM";
            if (dt == "12:01:01 AM")
            {
                sbc = true;
            }

            if (sbc)
            {
                //Logs.SendMessage("Batch No Clearing.....on" + date);
                Logs.ExcQuery();
                Logs.SendMessage("BatchNo. Cleared on " + date);
                return;
            }
            Logs.SendMessage("Started... " + date);

        }
        protected override void OnStop()
        {

            // after condition..
            this.timer.Stop();
            timer = null;
            Logs.SendMessage("Process has Stoped on " + DateTime.Now + ".....");
        }
    }
}
