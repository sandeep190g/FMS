﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;

namespace BatchNo
{

    public class Logs
    {
        public static string conStr = ConfigurationManager.ConnectionStrings["Logs"].ConnectionString;
        public static string strQuery;
        public static SqlConnection con = new SqlConnection(conStr);
        public static void SendMessage(string msg)
        {
            StreamWriter sw = null;
            try
            {

                string date = System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
                string filePath = "D:\\Logs.txt";
                //if (!File.Exists(filePath))
                //    File.Create(filePath);

                //sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\CLasses\\Logs " + date + ".txt", true);
                sw = new StreamWriter(filePath, true);
                sw.WriteLine( msg);
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {
                sw.WriteLine(ex.Message);
            }
        }
        public static string queryStr()
        {
            return strQuery = "update tblBatchNo set BatchNo=0";
        }

        public static void conState()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        public static void ExcQuery()
        {
            Logs.conState();
            Logs.queryStr();
            using (SqlDataAdapter sDa = new SqlDataAdapter(strQuery, con))
            {
                using (DataSet ds = new DataSet())
                {
                    sDa.Fill(ds);
                }
            }
        }
    }
}
