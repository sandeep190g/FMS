﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbLogout.ServerClick += new EventHandler(lbLogout_Click);
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Home.aspx");
            }

        }
        private void lbLogout_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtStoreID.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Store ID')</script>");
            else if (txtItemName.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Item Name')</script>");
            else if (txtExpTime.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Exp Time')</script>");
            else if (txtDuration.Text.Trim() == "")
                Response.Write("<script>alert('Enter valid Duration')</script>");



        }
    }
}