﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace FMS
{
    public partial class UserHome : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["FMS"].ConnectionString);
        private bool iBtnPrev = false;
        private bool iBtnNext = false;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
                lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
                timeStatus();
                selectItem();
                lblItemName.Text = ddlItem.SelectedItem.Text;
            }
        }
        public void selectItem()
        {
            con.Open();
            string query = "select ItemName from tblCooking order by ItemName Asc";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string itm = ds.Tables[0].Rows[i][0].ToString();
                    ddlItem.Items.Add(itm);
                }
            }
        }
        public void timeStatus()
        {
            TimeSpan timeMorn = new TimeSpan(4, 1, 1);
            TimeSpan endMorn = new TimeSpan(11, 59, 1);
            TimeSpan timeNoon = new TimeSpan(12, 1, 1);
            TimeSpan endNoon = new TimeSpan(16, 59, 1);
            TimeSpan timeEve = new TimeSpan(17, 1, 1);
            TimeSpan endEve = new TimeSpan(23, 59, 1);

            TimeSpan now = DateTime.Now.TimeOfDay;

            if ((now > timeMorn) && (now < endMorn))
            {
                ddlLunch.SelectedItem.Text = "  Breakfast  ";
            }
            else if ((now > timeNoon) && (now < endNoon))
            {
                ddlLunch.SelectedItem.Text = "   Lunch    ";
            }
            else if ((now > timeEve) && (now < endEve))
            {
                ddlLunch.SelectedItem.Text = "   Dinner  ";
            }
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            timeStatus();
        }

        protected void UpdateTimer_Tick(object sender, EventArgs e)
        {
            lblDate.Text = System.DateTime.Now.DayOfWeek.ToString() + "</br>" + DateTime.Now.ToString("MMMM dd,yyyy");
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        protected void Panel_Click()
        {
            if (iBtnNext)
            {
                int lblAmt = Convert.ToInt32(lblAmountCook.Text.Trim());

                lblAmountCook.Text = Convert.ToString(lblAmt + 1);
                ibPrev.Enabled = true;
            }
            else if (iBtnPrev)
            {
                int lblAmt = Convert.ToInt32(lblAmountCook.Text.Trim());
                if (lblAmt > 1)
                {
                    lblAmountCook.Text = Convert.ToString(lblAmt - 1);
                }
                else
                {
                    ibPrev.Enabled = false;
                }
            }

        }
        protected void ibNext_Click(object sender, ImageClickEventArgs e)
        {

            iBtnNext = true;
            Panel_Click();
        }

        protected void ibPrev_Click(object sender, ImageClickEventArgs e)
        {
            iBtnPrev = true;
            Panel_Click();
        }

        protected void ddlItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlItem.AutoPostBack = true;
           
            lblItemName.Text = ddlItem.SelectedItem.Text;
            ddlItem.DataBind();
        }
    }
}
