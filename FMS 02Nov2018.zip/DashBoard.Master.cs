﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace FMS
{
    public partial class DashBoard : System.Web.UI.MasterPage
    {
        HtmlElement html;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbLogout.ServerClick += new EventHandler(lbLogout_CLick);
            lbLogout2.ServerClick += new EventHandler(lbLogout_CLick);
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Home.aspx");
            }


        }
        protected void lbLogout_CLick(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Home.aspx");
        }
    }
}