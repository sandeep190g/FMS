﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace BatchNo
{
    public partial class Service1 : ServiceBase
    {
        string conStr = ConfigurationManager.ConnectionStrings["Logs"].ConnectionString;
        Logs lg = new Logs();
        private Timer timer = null;

        public Service1()
        {
            InitializeComponent();
        }

        public void ondebud()
        {

            timer_tick(null, null);
            //OnStart(null);
        }
        protected override void OnStart(string[] args)
        {
            //Logs.SendMessage("Timer is set for 10 seconds..");
            timer = new Timer();
            this.timer.Interval = 1000;
            this.timer.Elapsed += new ElapsedEventHandler(this.timer_tick);
            this.timer.Enabled = true;
            //timer_tick(null, null);
        }
        private void timer_tick(object sender, EventArgs e)
        {
            string date = System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
            bool sbc = false;
            //Logs.SendMessage("Some programs is running in background.....");
            // after condition..
            //TimeSpan dttt = DateTime.Now.TimeOfDay;
            string dt = DateTime.Now.ToString("hh:mm:ss tt");
            //string cDate = "12:00:01 AM";
            if (dt == "12:01:01 AM")
            {
                sbc = true;
            }


            if (sbc)
            {
                try
                {
                    lg.ExcQuery();
                    Logs.SendMessage("Success");
                }
                catch (Exception ex)
                {
                    Logs.SendMessage("Error.... " + ex.Message);
                }
            }
            else
            {
                Logs.SendMessage("Started from ...." + date);
            }
        }

        //timer_tick(null, null);

        protected override void OnStop()
        {

            // after condition..
            this.timer.Stop();
            timer = null;
            Logs.SendMessage("Process has Stoped on " + DateTime.Now + ".....");
        }
        public void sqlLogin()
        {
            String sqlServerLogin = "user_id";
            String password = "pwd";
            String instanceName = "sandeep";
            String remoteSvrName = "(localdb)\\MSSQLLocalDB";

            // Connecting to an instance of SQL Server using SQL Server Authentication  
            Server srv1 = new Server();   // connects to default instance  
            srv1.ConnectionContext.LoginSecure = false;   // set to true for Windows Authentication  
            srv1.ConnectionContext.Login = sqlServerLogin;
            srv1.ConnectionContext.Password = password;
            Console.WriteLine(srv1.Information.Version);   // connection is established  

            // Connecting to a named instance of SQL Server with SQL Server Authentication using ServerConnection  
            ServerConnection srvConn = new ServerConnection();
            srvConn.ServerInstance = @".\" + instanceName;   // connects to named instance  
            srvConn.LoginSecure = false;   // set to true for Windows Authentication  
            srvConn.Login = sqlServerLogin;
            srvConn.Password = password;
            Server srv2 = new Server(srvConn);
            Console.WriteLine(srv2.Information.Version);   // connection is established  

            // For remote connection, remote server name / ServerInstance needs to be specified  
            ServerConnection srvConn2 = new ServerConnection(remoteSvrName);
            srvConn2.LoginSecure = false;
            srvConn2.Login = sqlServerLogin;
            srvConn2.Password = password;
            Server srv3 = new Server(srvConn2);
            Console.WriteLine(srv3.Information.Version);
        }
    }
}
